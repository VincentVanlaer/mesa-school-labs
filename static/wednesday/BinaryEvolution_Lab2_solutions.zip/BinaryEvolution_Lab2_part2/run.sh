export OMP_NUM_THREADS=2

for beta in 0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9; do
	beta_d=$(printf "%.1fd0" $beta)
	sed -i '' "s/mass_transfer_beta = .*/mass_transfer_beta = ${beta_d}/" inlist_project
	sed -i '' "s/star_history_name = '.*'/star_history_name = 'history_beta${beta_d}_edd_mdot.data'/" inlist1

	./mk && ./rn | tee terminal_output_2cores_beta${beta_d}_edd_mdot.txt
done

export OMP_NUM_THREADS=8