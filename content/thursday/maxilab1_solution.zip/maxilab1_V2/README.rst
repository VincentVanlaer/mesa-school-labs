====================
MESA summer school 2025 Day 4 Maxilab Part 1
====================

This is the repository containing lab materials for the Day 4 Maxilab Part 1.
